package herramientas;

import figuras.Figura;

public class HerramientaDeSeleccion implements Herramienta {

	@Override
	public void pulsar(int x, int y) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mover(int x, int y) {
		// TODO Auto-generated method stub

	}

	@Override
	public Figura getFigura() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String nombreHerramienta() {
		return "Herramienta de seleccion";
	}


}
