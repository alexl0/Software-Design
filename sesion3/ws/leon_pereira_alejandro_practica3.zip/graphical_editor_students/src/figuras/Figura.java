package figuras;

public interface Figura {

	void dibujar();
	boolean isAcabada();
	void setAcabada(boolean acabada);
	
}
