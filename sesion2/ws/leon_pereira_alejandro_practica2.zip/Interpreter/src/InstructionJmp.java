
public class InstructionJmp implements Instruction {

	@Override
	public void execute() {
		// TODO Auto-generated method stub

	}

}
