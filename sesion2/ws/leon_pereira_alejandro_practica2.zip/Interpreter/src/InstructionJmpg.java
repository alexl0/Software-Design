
public class InstructionJmpg implements Instruction {

	@Override
	public void execute() {
		// TODO Auto-generated method stub

	}

}
