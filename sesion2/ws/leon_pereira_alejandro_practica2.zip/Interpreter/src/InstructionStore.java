
public class InstructionStore implements Instruction {

	@Override
	public void execute() {
		// TODO Auto-generated method stub

	}

}
