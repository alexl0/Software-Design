
public class InstructionInput implements Instruction {

	@Override
	public void execute() {
		// TODO Auto-generated method stub

	}

}
