
public class InstructionAdd implements Instruction {

	@Override
	public void execute() {
		Interpreter.push(5);

	}

}
