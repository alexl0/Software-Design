
public class InstructionLoad implements Instruction {

	@Override
	public void execute() {
		// TODO Auto-generated method stub

	}

}
